using nvidiaProfileInspector.Native.NVAPI2;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using nvw = nvidiaProfileInspector.Native.NVAPI2.NvapiDrsWrapper;

namespace nvidiaProfileInspector.Common
{
    public abstract class DrsSettingsServiceBase
    {
        public static readonly float DriverVersion;
        public static readonly string DriverBranch;

        protected DrsSettingsMetaService meta;
        protected DrsDecrypterService decrypter;

        static DrsSettingsServiceBase()
        {
            float version = 0f;
            string branch = "";
            uint sysDrvVersion = 0;
            var sysDrvBranch = new StringBuilder((int)NvapiDrsWrapper.NVAPI_SHORT_STRING_MAX);

            if (nvw.Instance.SYS_GetDriverAndBranchVersion(ref sysDrvVersion, sysDrvBranch) == NvAPI_Status.NVAPI_OK)
            {
                try { version = (float)(sysDrvVersion / 100f); }
                catch { }
                branch = sysDrvBranch.ToString();
            }

            DriverVersion = version;
            DriverBranch = branch;
        }

        public DrsSettingsServiceBase(DrsSettingsMetaService metaService, DrsDecrypterService decrpterService = null)
        {
            meta = metaService;
            decrypter = decrpterService;
        }

        protected void DrsSession(Action<IntPtr> action, bool forceNonGlobalSession = false, bool preventLoadSettings = false)
        {
            DrsSessionScope.DrsSession<bool>((hSession) =>
            {
                action(hSession);
                return true;
            }, forceNonGlobalSession: forceNonGlobalSession, preventLoadSettings: preventLoadSettings);
        }

        protected T DrsSession<T>(Func<IntPtr, T> action, bool forceDedicatedScope = false)
        {
            return DrsSessionScope.DrsSession<T>(action, forceDedicatedScope);
        }

        protected IntPtr GetProfileHandle(IntPtr hSession, string profileName)
        {
            var hProfile = IntPtr.Zero;

            if (string.IsNullOrEmpty(profileName))
            {
                var nvRes = nvw.Instance.DRS_GetCurrentGlobalProfile(hSession, ref hProfile);

                if (hProfile == IntPtr.Zero)
                    throw new NvapiException("DRS_GetCurrentGlobalProfile", NvAPI_Status.NVAPI_PROFILE_NOT_FOUND);

                if (nvRes != NvAPI_Status.NVAPI_OK)
                    throw new NvapiException("DRS_GetCurrentGlobalProfile", nvRes);
            }
            else
            {
                var nvRes = nvw.Instance.DRS_FindProfileByName(hSession, new StringBuilder(profileName), ref hProfile);

                if (nvRes == NvAPI_Status.NVAPI_PROFILE_NOT_FOUND)
                    return IntPtr.Zero;

                if (nvRes != NvAPI_Status.NVAPI_OK)
                    throw new NvapiException("DRS_FindProfileByName", nvRes);
            }
            return hProfile;
        }

        protected IntPtr CreateProfile(IntPtr hSession, string profileName)
        {
            if (string.IsNullOrEmpty(profileName))
                throw new ArgumentNullException("profileName");

            var hProfile = IntPtr.Zero;

            var newProfile = new NVDRS_PROFILE()
            {
                version = nvw.NVDRS_PROFILE_VER,
                profileName = profileName,
            };

            var nvRes = nvw.Instance.DRS_CreateProfile(hSession, ref newProfile, ref hProfile);
            if (nvRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_CreateProfile", nvRes);

            return hProfile;
        }


        protected NVDRS_PROFILE GetProfileInfo(IntPtr hSession, IntPtr hProfile)
        {
            var tmpProfile = new NVDRS_PROFILE();
            tmpProfile.version = nvw.NVDRS_PROFILE_VER;

            var gpRes = nvw.Instance.DRS_GetProfileInfo(hSession, hProfile, ref tmpProfile);
            if (gpRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_GetProfileInfo", gpRes);

            return tmpProfile;
        }

        protected void StoreSetting(IntPtr hSession, IntPtr hProfile, NVDRS_SETTING newSetting)
        {
            var ssRes = nvw.Instance.DRS_SetSetting(hSession, hProfile, ref newSetting);
            if (ssRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_SetSetting", ssRes);
        }

        protected void StoreDwordValue(IntPtr hSession, IntPtr hProfile, uint settingId, uint dwordValue)
        {
            var newSetting = new NVDRS_SETTING()
            {
                version = nvw.NVDRS_SETTING_VER,
                settingId = settingId,
                settingType = NVDRS_SETTING_TYPE.NVDRS_DWORD_TYPE,
                settingLocation = NVDRS_SETTING_LOCATION.NVDRS_CURRENT_PROFILE_LOCATION,
                currentValue = new NVDRS_SETTING_UNION()
                {
                    dwordValue = dwordValue,
                },
            };

            var ssRes = nvw.Instance.DRS_SetSetting(hSession, hProfile, ref newSetting);
            if (ssRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_SetSetting", ssRes);

        }

        protected void StoreQwordValue(IntPtr hSession, IntPtr hProfile, uint settingId, ulong qwordValue)
        {
            var newSetting = new NVDRS_SETTING()
            {
                version = nvw.NVDRS_SETTING_VER,
                settingId = settingId,
                settingType = NVDRS_SETTING_TYPE.NVDRS_QWORD_TYPE,
                settingLocation = NVDRS_SETTING_LOCATION.NVDRS_CURRENT_PROFILE_LOCATION,
                currentValue = new NVDRS_SETTING_UNION()
                {
                    qwordValue = qwordValue,
                },
            };

            var ssRes = nvw.Instance.DRS_SetSetting(hSession, hProfile, ref newSetting);
            if (ssRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_SetSetting", ssRes);

        }

        protected void StoreStringValue(IntPtr hSession, IntPtr hProfile, uint settingId, string stringValue)
        {
            var newSetting = new NVDRS_SETTING()
            {
                version = nvw.NVDRS_SETTING_VER,
                settingId = settingId,
                settingType = NVDRS_SETTING_TYPE.NVDRS_WSTRING_TYPE,
                settingLocation = NVDRS_SETTING_LOCATION.NVDRS_CURRENT_PROFILE_LOCATION,
                currentValue = new NVDRS_SETTING_UNION()
                {
                    stringValue = stringValue,
                },
            };

            var ssRes = nvw.Instance.DRS_SetSetting(hSession, hProfile, ref newSetting);
            if (ssRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_SetSetting", ssRes);

        }

        protected void StoreBinaryValue(IntPtr hSession, IntPtr hProfile, uint settingId, byte[] binValue)
        {
            var newSetting = new NVDRS_SETTING()
            {
                version = nvw.NVDRS_SETTING_VER,
                settingId = settingId,
                settingType = NVDRS_SETTING_TYPE.NVDRS_BINARY_TYPE,
                settingLocation = NVDRS_SETTING_LOCATION.NVDRS_CURRENT_PROFILE_LOCATION,
                currentValue = new NVDRS_SETTING_UNION()
                {
                    binaryValue = binValue,
                },
            };

            var ssRes = nvw.Instance.DRS_SetSetting(hSession, hProfile, ref newSetting);
            if (ssRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_SetSetting", ssRes);

        }

        protected NVDRS_SETTING? ReadSetting(IntPtr hSession, IntPtr hProfile, uint settingId)
        {
            var newSetting = new NVDRS_SETTING()
            {
                version = nvw.NVDRS_SETTING_VER,
            };

            var ssRes = nvw.Instance.DRS_GetSetting(hSession, hProfile, settingId, ref newSetting);
            if (ssRes == NvAPI_Status.NVAPI_SETTING_NOT_FOUND)
                return null;

            if (ssRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_GetSetting", ssRes);

            if (decrypter != null)
            {
                var profile = GetProfileInfo(hSession, hProfile);
                decrypter.DecryptSettingIfNeeded(profile.profileName, ref newSetting);
            }

            return newSetting;
        }

        protected uint? ReadDwordValue(IntPtr hSession, IntPtr hProfile, uint settingId)
        {
            var newSetting = ReadSetting(hSession, hProfile, settingId);
            if (newSetting == null)
                return null;
            return newSetting.Value.currentValue.dwordValue;
        }

        protected void AddApplication(IntPtr hSession, IntPtr hProfile, string applicationName)
        {
            var newApp = new NVDRS_APPLICATION_V4()
            {
                version = nvw.NVDRS_APPLICATION_VER_V4,
                appName = applicationName,
            };

            var caRes = nvw.Instance.DRS_CreateApplication(hSession, hProfile, ref newApp);

            if (caRes == NvAPI_Status.NVAPI_EXECUTABLE_ALREADY_IN_USE)
            {
                if (MitigateNvapiAlreadyInUseBug(hSession, hProfile, newApp)) return;
            }

            if (caRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_CreateApplication", caRes);

        }

        protected void AddApplication(IntPtr hSession, IntPtr hProfile, string applicationName, string fileInFolder)
        {
            var newApp = new NVDRS_APPLICATION_V4()
            {
                version = nvw.NVDRS_APPLICATION_VER_V4,
                appName = applicationName,
                fileInFolder = fileInFolder
            };

            var caRes = nvw.Instance.DRS_CreateApplication(hSession, hProfile, ref newApp);

            if (caRes == NvAPI_Status.NVAPI_EXECUTABLE_ALREADY_IN_USE)
            {
                if (MitigateNvapiAlreadyInUseBug(hSession, hProfile, newApp)) return;
            }


            if (caRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_CreateApplication", caRes);

        }

        protected bool MitigateNvapiAlreadyInUseBug(IntPtr hSession, IntPtr hProfile, NVDRS_APPLICATION_V4 pApplication)
        {
            var exeOnly = Path.GetFileName(pApplication.appName);
            if (exeOnly == pApplication.appName) return false;

            try
            {
                var fullMatchProfile = FindApplicationByName(hSession, pApplication.appName);
                if (fullMatchProfile == hProfile) return false;
            }
            catch (NvapiException e) {}


            IntPtr otherProfile = IntPtr.Zero;
            try
            {
                otherProfile = FindApplicationByName(hSession, exeOnly);
            }
            catch (NvapiException e)
            {
                return false;
            }

            if (otherProfile == hProfile) return false;

            var otherApps = GetProfileApplications(hSession, otherProfile);
            
            NVDRS_APPLICATION_V4 appToRestore = new NVDRS_APPLICATION_V4() { version = 1 };

            foreach (var app in otherApps)
            {
                if (app.appName.Equals(exeOnly, StringComparison.InvariantCultureIgnoreCase))
                {
                    DeleteApplication(hSession, otherProfile, app);
                    appToRestore = app;
                    break;
                }
            }

            if (appToRestore.version == 1) return false;

            var resCurrentProfile = nvw.Instance.DRS_CreateApplication(hSession, hProfile, ref pApplication);
            if (resCurrentProfile != NvAPI_Status.NVAPI_OK)
                throw new ApplicationException($"NVAPI Bug mitigation failed to add application '{pApplication.appName}' in current profile");

            var resOtherProfile = nvw.Instance.DRS_CreateApplication(hSession, otherProfile, ref appToRestore);
            if (resOtherProfile != NvAPI_Status.NVAPI_OK)
            {
                var profile = GetProfileInfo(hSession, otherProfile);
                throw new ApplicationException($"NVAPI Bug mitigation failed to restore application '{appToRestore.appName}' in profile '{profile.profileName}'");
            }

            return true;
        }


        protected void DeleteApplication(IntPtr hSession, IntPtr hProfile, NVDRS_APPLICATION_V4 application)
        {
            var caRes = nvw.Instance.DRS_DeleteApplicationEx(hSession, hProfile, ref application);
            if (caRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_DeleteApplication", caRes);
        }

        protected List<IntPtr> EnumProfileHandles(IntPtr hSession)
        {
            var profileHandles = new List<IntPtr>();
            var hProfile = IntPtr.Zero;
            uint index = 0;

            NvAPI_Status nvRes;

            do
            {
                nvRes = nvw.Instance.DRS_EnumProfiles(hSession, index, ref hProfile);
                if (nvRes == NvAPI_Status.NVAPI_OK)
                {
                    profileHandles.Add(hProfile);
                }
                index++;
            }
            while (nvRes == NvAPI_Status.NVAPI_OK);

            if (nvRes != NvAPI_Status.NVAPI_END_ENUMERATION)
                throw new NvapiException("DRS_EnumProfiles", nvRes);

            return profileHandles;
        }

        protected List<NVDRS_SETTING> GetProfileSettings(IntPtr hSession, IntPtr hProfile, uint expectedCount = 512)
        {
            uint settingCount = expectedCount > 0 ? expectedCount : 1;
            var settings = new NVDRS_SETTING[settingCount];
            settings[0].version = NvapiDrsWrapper.NVDRS_SETTING_VER;

            var esRes = NvapiDrsWrapper.Instance.DRS_EnumSettings(hSession, hProfile, 0, ref settingCount, ref settings);

            if (esRes == NvAPI_Status.NVAPI_END_ENUMERATION)
                return new List<NVDRS_SETTING>();

            if (esRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_EnumSettings", esRes);

            if (decrypter != null)
            {
                var profile = GetProfileInfo(hSession, hProfile);
                for (int i = 0; i < settingCount; i++)
                {
                    decrypter.DecryptSettingIfNeeded(profile.profileName, ref settings[i]);
                }
            }

            return settings.ToList();
        }

        protected List<NVDRS_APPLICATION_V4> GetProfileApplications(IntPtr hSession, IntPtr hProfile)
        {
            uint appCount = 512;
            var apps = new NVDRS_APPLICATION_V4[512];
            apps[0].version = NvapiDrsWrapper.NVDRS_APPLICATION_VER_V4;

            var esRes = NvapiDrsWrapper.Instance.DRS_EnumApplications(hSession, hProfile, 0, ref appCount, ref apps);

            if (esRes == NvAPI_Status.NVAPI_END_ENUMERATION)
                return new List<NVDRS_APPLICATION_V4>();

            if (esRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_EnumApplications", esRes);

            return apps.ToList();
        }

        protected IntPtr FindApplicationByName(IntPtr hSession, string appName)
        {
            IntPtr hProfile = IntPtr.Zero;
            NVDRS_APPLICATION_V4 app = new NVDRS_APPLICATION_V4();
            app.version = NvapiDrsWrapper.NVDRS_APPLICATION_VER_V4;

            var res = NvapiDrsWrapper.Instance.DRS_FindApplicationByName(hSession, new StringBuilder(appName), ref hProfile, ref app);

            if (res != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_FindApplicationByName", res);

            return hProfile;
        }

        protected void SaveSettings(IntPtr hSession)
        {
            var nvRes = nvw.Instance.DRS_SaveSettings(hSession);
            if (nvRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_SaveSettings", nvRes);
        }

        protected void LoadSettingsFileEx(IntPtr hSession, string filename)
        {
            var nvRes = nvw.Instance.DRS_LoadSettingsFromFileEx(hSession, new StringBuilder(filename));
            if (nvRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_LoadSettingsFromFileEx", nvRes);
        }

        protected void SaveSettingsFileEx(IntPtr hSession, string filename)
        {
            var nvRes = nvw.Instance.DRS_SaveSettingsToFileEx(hSession, new StringBuilder(filename));
            if (nvRes != NvAPI_Status.NVAPI_OK)
                throw new NvapiException("DRS_SaveSettingsToFileEx", nvRes);
        }

    }

}

